package org.douglasalvarado.contador;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
import org.douglasalvarado.main.Estadistica;


public class ObtenerController implements Initializable {
    private ArrayList<Integer> almacenDinamico =  new ArrayList<>();
    private int[] almacen;
    private Estadistica escenarioPrincipal;
    
    @FXML private Label lblAdvertencia1;
    @FXML private Label lblAdvertencia2;
    @FXML private TextField txtNumero;
    @FXML private TextField txtFrecuancia;
    @FXML private Button btnAgregar;
    @FXML private Button btnContinuar;
    
    public void dato(){
        if (!(txtNumero.getText().matches("[0-9]*"))) {
            lblAdvertencia2.setText("Solo Números Por favor");
        }else if(!(txtFrecuancia.getText().matches("[0-9]*"))){
            lblAdvertencia1.setText("Solo Números Por favor");
        }else if(txtNumero.getText().isEmpty()){
            lblAdvertencia2.setText("No dejar datos vacios");
        }else if(txtFrecuancia.getText().isEmpty()){
            lblAdvertencia1.setText("No dejar datos vacios");            
        }else{
            int valor = Integer.parseInt(txtNumero.getText());
            int dato = Integer.parseInt(txtFrecuancia.getText());
            for (int i = 0; i < dato; i++)
                almacenDinamico.add(valor);
            txtNumero.clear();
            txtFrecuancia.clear();
        }
    }
    
    public void finalizando(){
        if (!(almacenDinamico.isEmpty())) {
            Frecuencia f = new Frecuencia();
            almacen =  new int[almacenDinamico.size()];
            for (int i = 0; i < almacenDinamico.size(); i++) {
                almacen[i] = almacenDinamico.get(i);
            }
            f.setNumeros(almacen);
            f.getDato();
            escenarioPrincipal.Frecuencia();
        }else{
            JOptionPane.showMessageDialog(null, "No mostrara nada");
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    }

    public Estadistica getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Estadistica escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
}
