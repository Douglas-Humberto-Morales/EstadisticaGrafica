package org.douglasalvarado.contador;

import org.douglasalvarado.main.Estadistica;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.douglasalvarado.bean.Datos;

public class Frecuencia implements Initializable{
    // Investigar que pasa aqui
    private ObtenerController datos;
    private int[] numeros = {33, 25, 37, 37, 25, 37, 29, 41, 29, 33, 37, 25, 33, 37, 37, 37, 37, 33, 37, 33, 33, 41, 25, 37, 29};
    private String arreglo;
    private ArrayList<Integer> datosModa = new ArrayList<Integer>();
    private final Map<Integer, Integer> frecuenciaNumeros = new HashMap<>();
    private final Map<Integer, Integer> miHashMapOrdenado = new LinkedHashMap<>();
    private boolean seguir = true, seguir2 = true,seguir3 = true, seguir4 = true, seguir5 = true, medianaTF = true;

    private int XIResta = 0, acumuladorXI = 0, acumuladorXIF = 0, acumuladorXIF2 = 0, 
            acumuladorXIFT = 0, mediana = 0;
    
    private int Q1 = 0, Q2 = 0, Q3 = 0, P10 = 0,P90 = 0,
            Q1F = 0, Q2F = 0, Q3F = 0, P10F = 0,P90F = 0;
    
    private Datos dato = new Datos();
    
    private double acumuladorFR = 0.00,acumuladorFG = 0.00, valor = 0.0, resultado = 0.00,
            resultadoGrados = 0.00, resultadoPorcentaje = 0.00,valorXIT = 0.00, 
            fecuenciaTotal = 0.00,fa = 0.00,valorEntero=0.00, valorXI = 0.00, acumuladorPorcentaje = 0.00,
            SX = 0.00, S2 = 0.00, S = 0.00, CV = 0.00, sesgo = 0.00, curtosis = 0.00, acumuladorXF = 0.00,
            temp = 0.00, temp2 = 0.00, valorCV = 0.00;
    
    private ObservableList<Datos> listaDatos = FXCollections.observableArrayList();
    
    private Estadistica escenarioPrincipal;
    
    @FXML private Label lblX;
    @FXML private Label lblXAp;
    @FXML private Label lblMedia;
    @FXML private Label lblMediana;
    @FXML private Label lblModa;
    @FXML private Label txtF;
    @FXML private Label txtFr;
    @FXML private Label txtFg;
    @FXML private Label txtPorcentaje;
    @FXML private Label txtXIF;
    @FXML private Label txtXIXF;
    @FXML private Label txtXIXF2;
    @FXML private Label lblSX;
    @FXML private Label lblS2;
    @FXML private Label lblS;
    @FXML private Label lblCV;
    @FXML private Label lblQ1;
    @FXML private Label lblQ2;
    @FXML private Label lblQ3;
    @FXML private Label lblP10;
    @FXML private Label lblP90;
    @FXML private Label lblSesgo;
    @FXML private Label lblCurtosis;
    @FXML private TableView<Datos> tblDatos;
    @FXML private TableColumn<Datos, Integer> colXI;
    @FXML private TableColumn<Datos, Integer> colF;
    @FXML private TableColumn<Datos, Double> colFa;
    @FXML private TableColumn<Datos, Double> colFr;
    @FXML private TableColumn<Datos, Double> colFG;
    @FXML private TableColumn<Datos, Double> colPorcentaje;
    @FXML private TableColumn<Datos, Double> colXIF;
    @FXML private TableColumn<Datos, Double> colXIX;
    @FXML private TableColumn<Datos, Double> colXIXF;
    @FXML private TableColumn<Datos, Double> colXIX2;
    @FXML private TableColumn<Datos, Double> colXIXF2;
    
    
    public Frecuencia() {
    }
    
    public void getDato(){
        ordenar();
        for(Map.Entry<Integer, Integer> entry : miHashMapOrdenado.entrySet()){
            valorXI += entry.getKey()*entry.getValue();
        }
        valorXIT = Math.round(valorXI/fecuenciaTotal * 100.0) / 100.0;
        
//        int medianaFinal;
//        int mitad = miHashMapOrdenado.size() / 2;
//        // Si la longitud es par, se deben promediar los del centro
//        if (miHashMapOrdenado.size() % 2 == 0) {
//            medianaFinal = (miHashMapOrdenado.get(mitad) + miHashMapOrdenado.get(mitad + 1));
//        } else {
//            medianaFinal = miHashMapOrdenado.get(mitad);
//        }
        
        valorXI = (int) Math.round(((valorXI/fecuenciaTotal) * 100.0) / 100.0);
        System.out.println("Xi      F     Fa       Fr       FG      %       Xi*f     |Xi-X|   |Xi-X|*f   |Xi-X|^2   |Xi-X|^2*f");
        
        
        for(Map.Entry<Integer, Integer> entry : miHashMapOrdenado.entrySet()) {
            XIResta = (int) (entry.getKey()-valorXI);
            
            if (XIResta<0) 
                XIResta = XIResta*-1;
            
            fa += entry.getValue();
            valor = entry.getValue();
            valorEntero = entry.getValue();
            acumuladorXI += valorEntero * entry.getKey();

            
            resultado = Math.round((valor/fecuenciaTotal) * 100.0) / 100.0;
            acumuladorFR += resultado;
            
            resultadoGrados = Math.round(((valor*360)/fecuenciaTotal) * 100.0) / 100.0;
            acumuladorFG += resultadoGrados;
            
            resultadoPorcentaje = Math.round(((valor*100)/fecuenciaTotal)*100.0)/100.0;
            acumuladorPorcentaje += resultadoPorcentaje;
            
            acumuladorXIF += XIResta*entry.getValue();
            
            acumuladorXIF2 += (entry.getValue()*(XIResta*XIResta));
            
            acumuladorXF += valorEntero*entry.getKey();
            
            acumuladorXIFT += valorEntero*entry.getKey();
            
            
            
            System.out.println(entry.getKey()+ "     " +entry.getValue()+ "     " +fa+
                    "     " +resultado+"     " +resultadoGrados+"    "+resultadoPorcentaje+"    "+
                    valorEntero*entry.getKey()+ "           " +XIResta+ "        " +XIResta*entry.getValue()
            + "          " +XIResta*XIResta+ "          " +(entry.getValue()*(XIResta*XIResta)));
            
            Q1 = (int) Math.round((1*fecuenciaTotal)/4);
            Q2 = (int) Math.round((2*fecuenciaTotal)/4);
            Q3 = (int) Math.round((3*fecuenciaTotal)/4);
            P10 = (int) Math.round((10*fecuenciaTotal)/100);
            P90 = (int) Math.round((90*fecuenciaTotal)/100);
            
            if(seguir){
                if(Q1<=fa){
                    Q1F = entry.getKey();
                    seguir = false;
                }
            }
            if(seguir2){
                if(Q2<=fa){
                    Q2F = entry.getKey();
                    seguir2 = false;
                }
            }
            if(seguir3){
                if(Q3<=fa){
                    Q3F = entry.getKey();
                    seguir3 = false;
                }
            }
            if(seguir4){
                if(P10<=fa){
                    P10F = entry.getKey();
                    seguir4 = false;
                }
            }
            if(seguir5){
                if(P90<=fa){
                    P90F = entry.getKey();
                    seguir5 = false;
                }
            }
            
            if(mediana <= entry.getValue()){
                datosModa.add(entry.getKey());
                mediana = entry.getValue();
            }
            
            listaDatos.add(new Datos(entry.getKey(),entry.getValue(), fa, resultado,
            resultadoGrados, resultadoPorcentaje,(valorEntero*entry.getKey()),
            XIResta,(XIResta*entry.getValue()),(XIResta*XIResta), (entry.getValue()*(XIResta*XIResta))));
        }
        System.out.println("---------------------------");
        acumuladorFR = Math.round(acumuladorFR * 100.0) / 100.0;
        acumuladorPorcentaje = Math.round(acumuladorPorcentaje * 100.0) / 100.0;
        System.out.println("Suma  "+fecuenciaTotal+"             "+acumuladorFR+"     "+acumuladorFG+"   "+acumuladorPorcentaje+
                "             "+acumuladorXIFT+"         "+acumuladorXIF+"                     "+acumuladorXIF2);

        
        System.out.println("El valor de X = "+valorXIT+" aproximado = "+valorXI);
        
        System.out.println("El valor de la media = "+valorXIT);
        System.out.println("El valor de la mediana = "/*+medianaFinal*/);
        System.out.print("El valor de la moda = ");
        arreglo = datosModa.toString();
        for (int valor : datosModa) {
            System.out.print(valor + " ");
        }
        arreglo = arreglo.replace("[", "");
        arreglo = arreglo.replace("]", "");
        System.out.println("");
        
        SX = Math.round(acumuladorXIF/fecuenciaTotal * 100.0) / 100.0;
        S2 = Math.round((acumuladorXIF2/fecuenciaTotal)* 100.0) / 100.0; 
        S = Math.round((Math.sqrt(S2)) * 100.0) / 100.0;
        valorCV = (Math.round(S) * 100.0) / 100.0;
        CV = Math.round(((valorCV/valorXI)*100) * 100.0) / 100.0;

        temp = Q3F-Q1F;

        sesgo = Math.round(((Q3F-(2*Q2F)+Q1F)/temp) * 100.00)/100.00;        
        temp2 = 2*(P90F-P10F);
        curtosis = temp/temp2;
        
        System.out.println("");
        System.out.println("SX = "+SX+"   S^2 = "+S2+"   S = "+S+"  C.V. = "+CV);
        System.out.println("");
        
        System.out.println("Q1 = "+Q1F+"   Q2 = "+Q2F+"   Q3 = "+Q3F);
        System.out.println("");
        
        System.out.println("P10 = "+P10F+"  P90 = "+P90F);
        System.out.println("");
        
        System.out.println("El sesgo = "+sesgo+"  El curtosis = "+curtosis);
        String tipoSesgo = "";
        if(sesgo > 0.273)
            tipoSesgo = "Leptocúrtica";
        else if(sesgo < 0.273)
            tipoSesgo = "Platicúrtica";
        else
            tipoSesgo = "Mesocúrtica";
        System.out.println("Tipo de sesgo = "+tipoSesgo);
        System.out.println("");
        
        String tipoCurtosis = "";
        if(curtosis > 0)
            tipoCurtosis = "POSITIVO";
        else if(sesgo < 0)
            tipoCurtosis = "NEGATIVO";
        else
            tipoCurtosis = "CERO";
        System.out.println("Tipo de curtosis = "+tipoCurtosis);
        System.out.println("");
    }
    
    private void ordenar(){
        for(int numero : numeros){
            if(frecuenciaNumeros.containsKey(numero)) {
                frecuenciaNumeros.put(numero, frecuenciaNumeros.get(numero)+1);
            } else {
                frecuenciaNumeros.put(numero, 1);
            }
            fecuenciaTotal++;
        }
        // Convertir el HashMap a una lista de entradas y ordenarla por las claves
        List<Map.Entry<Integer, Integer>> listaOrdenada = new ArrayList<>(frecuenciaNumeros.entrySet());
        Collections.sort(listaOrdenada, new Comparator<Map.Entry<Integer, Integer>>() {
            public int compare(Map.Entry<Integer, Integer> entrada1, Map.Entry<Integer, Integer> entrada2) {
                return entrada1.getKey().compareTo(entrada2.getKey());
            }
        });
        // Crear un nuevo HashMap a partir de la lista ordenada
        for (Map.Entry<Integer, Integer> entrada : listaOrdenada) {
            miHashMapOrdenado.put(entrada.getKey(), entrada.getValue());
        }
    }

    public int[] getNumeros() {
        return numeros;
    }
    
    public void setNumeros(int[] numeros) {
        this.numeros = numeros;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        getDato();
        cargarDatos();
        ObservableList<Datos> lista = FXCollections.observableArrayList();
        lista.add(new Datos());
    }
    
    private void cargarDatos(){
        tblDatos.setItems(listaDatos);;
        colXI.setCellValueFactory(new PropertyValueFactory<>("XI"));
        colF.setCellValueFactory(new PropertyValueFactory<>("f"));
        colFa.setCellValueFactory(new PropertyValueFactory<>("fa"));
        colFr.setCellValueFactory(new PropertyValueFactory<>("resultado"));
        colFG.setCellValueFactory(new PropertyValueFactory<>("resultadoGrados"));
        colPorcentaje.setCellValueFactory(new PropertyValueFactory<>("resultadoPorcentaje"));
        colXIF.setCellValueFactory(new PropertyValueFactory<>("XIF"));
        colXIX.setCellValueFactory(new PropertyValueFactory<>("XIResta"));
        colXIXF.setCellValueFactory(new PropertyValueFactory<>("XIRestaF"));
        colXIX2.setCellValueFactory(new PropertyValueFactory<>("XIResta2"));
        colXIXF2.setCellValueFactory(new PropertyValueFactory<>("XIF2"));
        
        
        txtF.setText(String.valueOf(fecuenciaTotal));
        txtFr.setText(String.valueOf(acumuladorFR));
        txtFg.setText(String.valueOf(acumuladorFG));
        txtPorcentaje.setText(String.valueOf(acumuladorPorcentaje));
        txtXIF.setText(String.valueOf(acumuladorXIFT));
        txtXIXF.setText(String.valueOf(acumuladorXIF));
        txtXIXF2.setText(String.valueOf(acumuladorXIF2));
        
        
        lblX.setText(String.valueOf(valorXIT));
        lblXAp.setText(String.valueOf(valorXI));
        
        
        lblMedia.setText(String.valueOf(valorXIT));
        lblMediana.setText(String.valueOf("Nulo"));
        lblModa.setText(String.valueOf(arreglo));
        
        
        lblSX.setText(String.valueOf(SX));
        lblS2.setText(String.valueOf(S2));
        lblS.setText(String.valueOf(S));
        lblCV.setText(String.valueOf(CV));
        
        lblQ1.setText(String.valueOf(Q1F));
        lblQ2.setText(String.valueOf(Q2F));
        lblQ3.setText(String.valueOf(Q3F));
        
        lblP10.setText(String.valueOf(P10F));
        lblP90.setText(String.valueOf(P90F));
        
        
        lblSesgo.setText(String.valueOf(sesgo));
        lblCurtosis.setText(String.valueOf(curtosis));
    }
    
    public Estadistica getEscenarioPrincipan(){
        return escenarioPrincipal;
    }
    
    public void setEscenarioPrincipal(Estadistica escenarioPrincipal){
        this.escenarioPrincipal = escenarioPrincipal;
    }
}