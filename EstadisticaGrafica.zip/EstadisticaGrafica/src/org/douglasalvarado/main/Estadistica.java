/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.douglasalvarado.main;

import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.douglasalvarado.contador.Frecuencia;
import org.douglasalvarado.contador.ObtenerController;

/**
 *
 * @author dougl
 */
public class Estadistica extends Application {
    private final String PAQUETE_VISTA = "/org/douglasalvarado/view/";
    private Stage escenarioPrincipal;
    private Scene escena;
    
    @Override
    public void start(Stage escenarioPrincipal)throws Exception{
        this.escenarioPrincipal = escenarioPrincipal;
        escenarioPrincipal.setTitle("Estadistica Avanzada");
        Frecuencia();
        escenarioPrincipal.show();
    }

    public void Frecuencia(){
        try {
            Frecuencia frecuencia = (Frecuencia)cambiarEscena("DatosView.fxml",821,359);
            frecuencia.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void Obtener(){
        try {
            ObtenerController obtener = (ObtenerController)cambiarEscena("ObtenerView.fxml",372,131);
            obtener.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public Initializable cambiarEscena(String fxml, int ancho, int alto) throws Exception{
        Initializable resultado = null;
        FXMLLoader cargadorFXML  = new FXMLLoader();
        InputStream archivo = Estadistica.class.getResourceAsStream(PAQUETE_VISTA+fxml); 
        cargadorFXML.setBuilderFactory(new JavaFXBuilderFactory());
        cargadorFXML.setLocation(Estadistica.class.getResource(PAQUETE_VISTA+fxml));
        escena = new Scene((AnchorPane)cargadorFXML.load(archivo), ancho, alto);
        escenarioPrincipal.setScene(escena);
        escenarioPrincipal.sizeToScene();
        resultado = (Initializable)cargadorFXML.getController();
        return resultado;
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}