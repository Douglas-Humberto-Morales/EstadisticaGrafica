package org.douglasalvarado.bean;


public class Datos {

    private double XI,f,fa,resultado,
            resultadoGrados, resultadoPorcentaje, XIF,
            XIResta, XIRestaF, XIResta2,XIF2;

    public Datos() {
    }
    
    public Datos(int XI,int f,double fa,double resultado,
            double resultadoGrados, double resultadoPorcentaje, double XIF,
            double XIResta, double XIRestaF,double XIResta2,double XIF2){
        this.XI = XI;
        this.f = f;
        this.fa = fa;
        this.resultado = resultado;
        this.resultadoGrados = resultadoGrados;
        this.resultadoPorcentaje = resultadoPorcentaje;
        this.XIF = XIF;
        this.XIResta = XIResta;
        this.XIRestaF = XIRestaF;
        this.XIResta2 = XIResta2;
        this.XIF2 = XIF2;
    }

    public double getXI() {
        return XI;
    }

    public void setXI(double XI) {
        this.XI = XI;
    }

    public double getF() {
        return f;
    }

    public void setF(double f) {
        this.f = f;
    }

    public double getFa() {
        return fa;
    }

    public void setFa(double fa) {
        this.fa = fa;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }

    public double getResultadoGrados() {
        return resultadoGrados;
    }

    public void setResultadoGrados(double resultadoGrados) {
        this.resultadoGrados = resultadoGrados;
    }

    public double getResultadoPorcentaje() {
        return resultadoPorcentaje;
    }

    public void setResultadoPorcentaje(double resultadoPorcentaje) {
        this.resultadoPorcentaje = resultadoPorcentaje;
    }

    public double getXIF() {
        return XIF;
    }

    public void setXIF(double XIF) {
        this.XIF = XIF;
    }

    public double getXIResta() {
        return XIResta;
    }

    public void setXIResta(double XIResta) {
        this.XIResta = XIResta;
    }

    public double getXIRestaF() {
        return XIRestaF;
    }

    public void setXIRestaF(double XIRestaF) {
        this.XIRestaF = XIRestaF;
    }

    public double getXIResta2() {
        return XIResta2;
    }

    public void setXIResta2(double XIResta2) {
        this.XIResta2 = XIResta2;
    }

    public double getXIF2() {
        return XIF2;
    }

    public void setXIF2(double XIF2) {
        this.XIF2 = XIF2;
    }
}
